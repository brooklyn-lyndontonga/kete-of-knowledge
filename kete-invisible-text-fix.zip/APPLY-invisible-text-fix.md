# Fix: invisible typed text (app + CMS) — the team's two bugs

Apply from the repo root:
    git apply APPLY-... wait, use the patch:
    git apply invisible-text-fix.patch
    git add -A
    git commit -m "fix: explicit text colour on all inputs (app + admin) — typed text was invisible under OEM force-dark / theme mismatch"
    git push

What it does:
- Mobile app: adds `color: colors.text` to all 18 input styles across 12
  screens (sign-in, symptoms, medicines, notes, reminders, checklists,
  goals, profile, reflections, search). Root cause of "couldn't type
  anything": Android OEM force-dark flipped default text to white on the
  app's white input cards. Every text entry point was affected.
- Admin CMS: adds explicit text + caret colour for ALL inputs, textareas,
  selects and rich-text areas in both light and dark themes. Root cause
  of "cannot see the font when you type into a section": light background
  was forced but text colour was only defined for class-based dark-mode
  inputs.

After pushing:
- CMS fix goes live when the admin panel redeploys — tell Kory to hard-
  refresh (Cmd+Shift+R) and try typing in a section again.
- App fix requires a NEW Android build:  ./release-beta.sh --platform android
  → send the team the new install link (and it'll be in the first iOS build).
